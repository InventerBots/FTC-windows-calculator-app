//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Texplanation *explanation;
//---------------------------------------------------------------------------
__fastcall Texplanation::Texplanation(TComponent* Owner)
	: TFrame(Owner)
{
}
//---------------------------------------------------------------------------
